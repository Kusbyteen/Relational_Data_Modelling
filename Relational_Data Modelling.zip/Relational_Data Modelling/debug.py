import psycopg2

conn = psycopg2.connect("host=127.0.0.1  dbname=debug user=postgres password=root")
cur = conn.cursor()

cur.execute("CREATE TABLE songplays(songplay_id VARCHAR(100), start_time VARCHAR(100), user_id VARCHAR(100), level VARCHAR(20), song_id VARCHAR(100), artist_id VARCHAR(100), session_id INTEGER, location VARCHAR(50), user_agent VARCHAR(100))")
# query  = "INSERT INTO songplays(songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user"
# 'jdie', 2018-11-10, 'dowi245', 2,'1234', '378264', 12, 'Wa', 'eiw3'
query = "INSERT INTO songplays(songplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent) VALUES (%s, %s, %s, %s,%s, %s, %s, %s, %s)"
cur.execute(query, 'jdie', 2018-11-10, 'dowi245', 2,'1234', '378264', 12, 'Wa', 'eiw3')

cur.execute("SELECT * FROM songplays")
for row in cur.fetchall():
    print(row)